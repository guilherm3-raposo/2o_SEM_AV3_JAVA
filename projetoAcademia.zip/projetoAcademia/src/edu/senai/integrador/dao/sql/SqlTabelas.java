package edu.senai.integrador.dao.sql;

public class SqlTabelas {
	public final String CONTATO			= (LeXml.getTag("tabelas")[0]);
	public final String ENDERECO		= (LeXml.getTag("tabelas")[1]);
	public final String PESSOA			= (LeXml.getTag("tabelas")[2]);
	public final String ALUNO			= (LeXml.getTag("tabelas")[3]);
	public final String FUNCIONARIO		= (LeXml.getTag("tabelas")[4]);
	public final String TURMA			= (LeXml.getTag("tabelas")[5]);
	public final String MODALIDADE		= (LeXml.getTag("tabelas")[6]);
}
