package edu.senai.integrador.dao.sql;

public class ColunasContato {
	private String[] tags = LeXml.getTag("colunasContato");
	
	public final String CPF = (tags[0]);
	public final String FIXO = (tags[1]);
	public final String MOVEL = (tags[2]);
	public final String EMAIL = (tags[3]);
}
