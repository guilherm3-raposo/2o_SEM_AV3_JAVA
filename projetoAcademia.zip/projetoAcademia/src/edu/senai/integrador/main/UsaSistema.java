package edu.senai.integrador.main;

public class UsaSistema {

}
