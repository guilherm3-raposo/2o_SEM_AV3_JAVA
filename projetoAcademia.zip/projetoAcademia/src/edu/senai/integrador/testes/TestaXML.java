package edu.senai.integrador.testes;

import edu.senai.integrador.bancodedados.conexao.ConexaoException;
import edu.senai.integrador.beans.exception.PessoaException;
import edu.senai.integrador.dao.DAOException;

public class TestaXML {
	public static void main(String[] args) throws ConexaoException, DAOException, PessoaException {
//		Map<Integer, Aluno> alunos = new HashMap<Integer, Aluno>();
//		AlunoDAO alunoDAO = new AlunoDAO();
//		try {
//			for (int i = 0; i < 50; i++) {
//				alunos.put(i, Instanciador.criaAluno(i));
//			}
//			alunoDAO.insereVarios(alunos);
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//		alunos = alunoDAO.consultaTodos();
//		alunoDAO.exclui(alunos.get(0));	
//		OperacaoXml xml = new OperacaoXml();
//		String[] tabelas = xml.getNomeTabelas();
//		for (int i = 0; i < tabelas.length; i++) {
//			System.out.println(tabelas[i]);
//		}
//		Map<Integer, Funcionario> funcionarios = new HashMap<Integer, Funcionario>();
//		FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
//		for (int i = 0; i < 50; i++) {
//			funcionarios.put(i, Instanciador.criaFuncionario(i));			
//		}
//		funcionarioDAO.insereVarios(funcionarios);
//		funcionarios = funcionarioDAO.consultaTodos();
//		funcionarios.forEach((indice, funcionario) -> System.out.println(funcionario + "\n"));
//		Funcionario funcionario = funcionarios.get(0);
//		System.out.println(funcionario);
//		funcionario.setCtps("0");
//		System.out.println(funcionario);
//		funcionarioDAO.exclui(funcionario);
	}
}
