package edu.senai.integrador.testes;

import edu.senai.integrador.beans.exception.FuncionarioException;
import edu.senai.integrador.beans.exception.PessoaException;

public class TestaFuncionario {
	public static void main(String[] args) throws PessoaException, FuncionarioException {
//		Funcionario funcionario = new Funcionario("99988877722", "98765432110", EEscolaridade.SUPERIOR_INCOMPLETO,
//				"Creusa", LocalDate.of(2000, 05, 01), ESexo.FEMININO, EEstadoCivil.SEPARADO);

//		Funcionario funcionario2 = new Funcionario();
//
//		System.out.print("Digite o CPF do funcionario_____________________ ");
//		funcionario2.setCPF(LeituraTerminal.leCpf());
//
//		System.out.print("Digite o nome do funcionario____________________ ");
//		funcionario2.setNome(LeituraTerminal.leString());
//
//		System.out.print("Digite a data de nascimento do funcionario______ ");
//		funcionario2.setDataDeNascimento(LeituraTerminal.leData());
//
//		System.out.print("Digite o sexo do funcionario (M/F)______________ ");
//		funcionario2.setSexo(LeituraTerminal.leSexo());
//
//		System.out.print("1- Rua\t2- Avenida\t3- Alameda\t4- Rodovia\t5-Vila\n");
//		System.out.println("Digite o c�digo do Logradouro___________________ ");
//		funcionario2.setLogradouro(LeituraTerminal.leLogradouro());
//
//		System.out.print("Digite o endere�o_______________________________ ");
//		funcionario2.setEndereco(LeituraTerminal.leString());
//
//		System.out.print("Digite o n�mero_________________________________ ");
//		funcionario2.setNumeroCasa(LeituraTerminal.leInt());
//
//		System.out.print("Digite o complemento____________________________ ");
//		funcionario2.setComplemento(LeituraTerminal.leString());
//
//		System.out.print("Digite o telefone do funcionario________________ ");
//		funcionario2.setTelefone(LeituraTerminal.leString());
//
//		System.out.print("Digite o email do funcionario___________________ ");
//		funcionario2.setEmail(LeituraTerminal.leString());
//
//		System.out.print("1- solteiro(a)\t2- casado(a)\t3- divorciado(a)\t4- separado(a)");
//		System.out.println("Digite o estado civil do funcionario____________ ");
//		funcionario2.setEstadoCivil(LeituraTerminal.leEstadoCivil());
//
//		System.out.print("Digite o n�mero da CTPS_________________________ ");
//		funcionario2.setCtps(LeituraTerminal.leString());
//
//		System.out.print("1- Fundamental inc.\t2- fundamental comp.\t3- m�dio inc.\t4- m�dio comp.\t5- superior inc.\n6- superior comp.");
//		System.out.print("Digite o c�digo da escolaridade_________________ ");
//		funcionario2.setEscolaridade(LeituraTerminal.leEscolaridade());
//
//		System.out.println(funcionario.toString() + "\n");
//
//		FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
//		try {
//			funcionarioDAO.insere(funcionario);
//			System.out.println(funcionarioDAO.consulta(Long.valueOf(funcionario.getCPF())));
//
//		} catch (ConexaoException | DAOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println(funcionario2.toString());
	}
}
