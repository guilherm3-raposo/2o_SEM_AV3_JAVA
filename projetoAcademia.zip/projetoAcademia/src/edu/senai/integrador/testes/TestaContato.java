package edu.senai.integrador.testes;

import java.sql.SQLException;

import edu.senai.integrador.bancodedados.conexao.ConexaoException;
import edu.senai.integrador.beans.Contato;
import edu.senai.integrador.dao.ContatoDAO;
import edu.senai.integrador.dao.DAOException;

public class TestaContato {
	public static void main(String[] args) throws ConexaoException, DAOException, SQLException {
		Contato contato = new Contato("77788899922","36677889","998123989","tentando@email.com");
		ContatoDAO contatodao = new ContatoDAO();
//		System.out.println(contatodao.insere(contato));
		System.out.println(contatodao.consulta("33322244411"));
//		System.out.println(contatodao.consultaTodos());
//		System.out.println(contatodao.consultaTodos());
	}
}
